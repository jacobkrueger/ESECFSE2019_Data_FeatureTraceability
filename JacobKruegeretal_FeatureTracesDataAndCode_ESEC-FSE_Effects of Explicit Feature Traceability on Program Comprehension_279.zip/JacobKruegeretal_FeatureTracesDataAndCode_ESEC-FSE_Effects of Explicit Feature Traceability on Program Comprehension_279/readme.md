
##### This repository comprises the artifacts belonging to the accepted ESCE/FSE 2019 submission:

##### Jacob Krüger, Gül  Calıklı, Thorsten Berger, Thomas Leich, and Gunter Saake. Effects of Explicit Feature Traceability on Program Comprehension.



This artifact comprises two parts:
1. The source code of our experiment to allow for replications.
2. The anonymous results of our experiment to verify the results we obtained in the paper.
---

How to set up the experiment with an unprotected server in XAMPP and without mail sending capabilities:
1. Download and isntall XAMPP: <https://www.apachefriends.org/de/index.html>
2. Start Apache Server and MySQL
3. Define user, password etc. fot the database in dbConnect.php
4. Set up participants.txt in the form: mail,code; where code can be one of the following: "annotated","components" or "object-oriented", depending on the version the participant shall see
5. Execute <http://localhost/survey/php/setUpDB.php> to set up the database, all tables and the experiment
6. We remark again that we disabled automated mail sending! For this reason, you have to manually set exp_1_sent to a value (the current date), otherwise the system will not recognize that the user was already invited
7. Then, you can go into a browser and call: localhost/survey/index.php?id=-id- ; where -id- refers to the urlkey entry in the user tables
8. This should result in the experiment running and storing data
9. To access and see the resulting data, go into phpMyAdmin and have a look into the databases that store the corresponding data

---
We contribute the results (2.) in the results.csv, where the following applies:
+ Userkey is a hash value that identified entries of the same participant
+ Code refers to the source code the participant has been shown (annotated, components, object-oriented)
+ Set refers to whether the participant stated confusion/disruptions (external) or not (internal)
+ Disturbed refers to tasks for which the participant stated disturbances
+ Page refers to the task that was solved in this entry
+ Time reports the required time in milliseconds
+ Response states the selected response of the participant
+ Correct identifies whether the selected response was correct or not

We remark that the last entry of participants (page is 10) shows only parts of this data, as it was a qualitative response on the used strategy to comprehend the source code and how to improve its structure.