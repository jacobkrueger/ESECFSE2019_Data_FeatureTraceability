<div id='IncludePhoto.java_1' class='line'><div class='lineNumber' id='hl_1'>1 |</div><div class='code'><span class='keyword'>public</span> <span class='keyword'>class</span> IncludePhoto{</div> </div>
<div id='IncludePhoto.java_2' class='line'><div class='lineNumber' id='hl_2'>2 |</div><div class='code'><span class='empty'> </span></div> </div>
<div id='IncludePhoto.java_3' class='line'><div class='lineNumber' id='hl_3'>3 |</div><div class='code'>  <span class='keyword'>public</span> <span class='keyword'>static</span> <span class='keyword'>boolean</span> checkLabel(String label) {</div> </div>
<div id='IncludePhoto.java_4' class='line'><div class='lineNumber' id='hl_4'>4 |</div><div class='code'>    <span class='keyword'>if</span> (label.<wbr>equals(<span class='string'>"View"</span>)) {</div> </div>
<div id='IncludePhoto.java_5' class='line'><div class='lineNumber' id='hl_5'>5 |</div><div class='code'>      String selectedImageName = getSelectedMediaName();</div> </div>
<div id='IncludePhoto.java_6' class='line'><div class='lineNumber' id='hl_6'>6 |</div><div class='code'>      showImage(selectedImageName);</div> </div>
<div id='IncludePhoto.java_7' class='line'><div class='lineNumber' id='hl_7'>7 |</div><div class='code'>      IncludeSorting.<wbr>incrementCountViews(selectedImageName);</div> </div>
<div id='IncludePhoto.java_8' class='line'><div class='lineNumber' id='hl_8'>8 |</div><div class='code'>      ScreenSingleton.<wbr>getInstance().<wbr>setCurrentScreenName(Constants.<wbr>IMAGE_SCREEN);</div> </div>
<div id='IncludePhoto.java_9' class='line'><div class='lineNumber' id='hl_9'>9 |</div><div class='code'>      <span class='keyword'>return</span> <span class='keyword'>true</span>;</div> </div>
<div id='IncludePhoto.java_10' class='line'><div class='lineNumber' id='hl_10'>10 |</div><div class='code'>    }</div> </div>
<div id='IncludePhoto.java_11' class='line'><div class='lineNumber' id='hl_11'>11 |</div><div class='code'>    <span class='keyword'>return</span> <span class='keyword'>false</span>;</div> </div>
<div id='IncludePhoto.java_12' class='line'><div class='lineNumber' id='hl_12'>12 |</div><div class='code'>  }</div> </div>
<div id='IncludePhoto.java_13' class='line'><div class='lineNumber' id='hl_13'>13 |</div><div class='code'><span class='empty'> </span></div> </div>
<div id='IncludePhoto.java_14' class='line'><div class='lineNumber' id='hl_14'>14 |</div><div class='code'>  <span class='keyword'>public</span> <span class='keyword'>void</span> showImage(String name) {</div> </div>
<div id='IncludePhoto.java_15' class='line'><div class='lineNumber' id='hl_15'>15 |</div><div class='code'>    Image storedImage = <span class='keyword'>null</span>;</div> </div>
<div id='IncludePhoto.java_16' class='line'><div class='lineNumber' id='hl_16'>16 |</div><div class='code'>    <span class='keyword'>try</span> {</div> </div>
<div id='IncludePhoto.java_17' class='line'><div class='lineNumber' id='hl_17'>17 |</div><div class='code'>      storedImage = ((ImageAlbumData)getAlbumData()).<wbr>getImageFromRecordStore(getCurrentStoreName(), name);</div> </div>
<div id='IncludePhoto.java_18' class='line'><div class='lineNumber' id='hl_18'>18 |</div><div class='code'>    } <span class='keyword'>catch</span> (ImageNotFoundException e) {</div> </div>
<div id='IncludePhoto.java_19' class='line'><div class='lineNumber' id='hl_19'>19 |</div><div class='code'>      Alert alert = <span class='keyword'>new</span> Alert( <span class='string'>"Error"</span>, <span class='string'>"The selected photo was not found in the mobile device"</span>, <span class='keyword'>null</span>, AlertType.<wbr>ERROR);</div> </div>
<div id='IncludePhoto.java_20' class='line'><div class='lineNumber' id='hl_20'>20 |</div><div class='code'>      Display.<wbr>getDisplay(midlet).<wbr>setCurrent(alert, Display.<wbr>getDisplay(midlet).<wbr>getCurrent());</div> </div>
<div id='IncludePhoto.java_21' class='line'><div class='lineNumber' id='hl_21'>21 |</div><div class='code'>          <span class='keyword'>return</span>;</div> </div>
<div id='IncludePhoto.java_22' class='line'><div class='lineNumber' id='hl_22'>22 |</div><div class='code'>    } <span class='keyword'>catch</span> (PersistenceMechanismException e) {</div> </div>
<div id='IncludePhoto.java_23' class='line'><div class='lineNumber' id='hl_23'>23 |</div><div class='code'>      Alert alert = <span class='keyword'>new</span> Alert( <span class='string'>"Error"</span>, <span class='string'>"The mobile database can open <span class='keyword'>this</span> photo"</span>, <span class='keyword'>null</span>, AlertType.<wbr>ERROR);</div> </div>
<div id='IncludePhoto.java_24' class='line'><div class='lineNumber' id='hl_24'>24 |</div><div class='code'>      Display.<wbr>getDisplay(midlet).<wbr>setCurrent(alert, Display.<wbr>getDisplay(midlet).<wbr>getCurrent());</div> </div>
<div id='IncludePhoto.java_25' class='line'><div class='lineNumber' id='hl_25'>25 |</div><div class='code'>          <span class='keyword'>return</span>;</div> </div>
<div id='IncludePhoto.java_26' class='line'><div class='lineNumber' id='hl_26'>26 |</div><div class='code'>    }    </div> </div>
<div id='IncludePhoto.java_27' class='line'><div class='lineNumber' id='hl_27'>27 |</div><div class='code'><span class='empty'> </span></div> </div>
<div id='IncludePhoto.java_28' class='line'><div class='lineNumber' id='hl_28'>28 |</div><div class='code'>    PhotoViewScreen canv = <span class='keyword'>new</span> PhotoViewScreen(storedImage);</div> </div>
<div id='IncludePhoto.java_29' class='line'><div class='lineNumber' id='hl_29'>29 |</div><div class='code'>    canv.<wbr>setCommandListener( <span class='keyword'>this</span> );</div> </div>
<div id='IncludePhoto.java_30' class='line'><div class='lineNumber' id='hl_30'>30 |</div><div class='code'>    AbstractController nextcontroller = <span class='keyword'>this</span>; </div> </div>
<div id='IncludePhoto.java_31' class='line'><div class='lineNumber' id='hl_31'>31 |</div><div class='code'>    IncludeCopyMedia.<wbr>addControler(nextcontroller, canv);</div> </div>
<div id='IncludePhoto.java_32' class='line'><div class='lineNumber' id='hl_32'>32 |</div><div class='code'><span class='empty'> </span></div> </div>
<div id='IncludePhoto.java_33' class='line'><div class='lineNumber' id='hl_33'>33 |</div><div class='code'>    setCurrentScreen(canv);</div> </div>
<div id='IncludePhoto.java_34' class='line'><div class='lineNumber' id='hl_34'>34 |</div><div class='code'>  }</div> </div>
<div id='IncludePhoto.java_35' class='line'><div class='lineNumber' id='hl_35'>35 |</div><div class='code'>}</div> </div>

