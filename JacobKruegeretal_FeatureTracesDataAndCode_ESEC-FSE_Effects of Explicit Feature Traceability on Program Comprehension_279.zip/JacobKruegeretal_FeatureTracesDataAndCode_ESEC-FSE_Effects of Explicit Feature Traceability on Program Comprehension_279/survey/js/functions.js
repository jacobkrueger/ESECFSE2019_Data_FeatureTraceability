	
	// measure times (maybe better on server side?) and mouse click event
	var $start = new Date();
	var $end = new Date();
	var $mouse = false;
	var $page = 0;
	var icons = {
	  header: "ui-icon-circle-arrow-e",
	  activeHeader: "ui-icon-circle-arrow-s"
	};

$( document ).ready(function() {
	// some positioning stuff
	$( "#content" ).css( "margin-top", ($( "#fixed" ).height() +15) );
	
	// get initial (i.e., 1st or reloaded page) content
	next("setUp");
	
	// continue with next question
	$( "#next" ).click(function() {
		// this is a checking mechnism
		switch ($page) {
			// checkboxes
			case 3:
			case 5:
				// select ids of all checkboxes
				$postValues = $( ":checked" ).map(function() {
						return $( this ).val();
					}).get().join(";");

				if (typeof $postValues === 'undefined' || $postValues === null || $postValues === "") alert("Please provide an answer to the question(s).");
				else {
					// measure submit date for question and send response
					$end = new Date();
					next($postValues);
				}
				break;
			// select lines
			case 4:
			case 7:
			case 8:
			case 9:
				// select ids of all selected lines
				$postValues = $( ".selectedResponse" ).map(function() {
					return $( this ).attr("id");
				}).get().join(";");
				
				if (typeof $postValues === 'undefined' || $postValues === null || $postValues === "") alert("Please provide an answer to the question(s).");
				else {
					// measure submit date for question and send response
					$end = new Date();
					next($postValues);
				}
				break;
			// opinion page
		   
		   
			case 10:
				/*if (alert("It seems you did not make any selections and are trying to send an empty response. Are you sure?")) {	
					$postValues = "";
					next($postValues);
				}*/
				if (! $( "#comprehending_y_n > :checked" ).length > 0 ||
					! $( "#strategy_Answer" ).val().trim().length > 0 ||
					! $( "#challenges_Answer" ).val().trim().length > 0 ||
					! $( "#design_Answer" ).val().trim().length > 0
				)
					alert("Please provide an answer to the question(s).");
				else {
					$postValues = $( "#comprehending_y_n > :checked" ).val() + ";" +
					"Strat: " + $( "#strategy_Answer" ).val().trim().replace(/;/g,"_") + ";" +
					"Chall: " + $( "#challenges_Answer" ).val().trim().replace(/;/g,"_") + ";" +
					"Design: " + $( "#design_Answer" ).val().trim().replace(/;/g,"_") + ";" +
					$( "#interruption_Answer > :checked" ).map(function() {
							return $( this ).val();
						}).get().join("_") + ";" +
					$( "#comments_Answer" ).val().trim().replace(/;/g,"_");
					$end = new Date();
					next($postValues);
				}
				break;
			default:
				$postValues = "";
				$end = new Date();
				next($postValues);
				break;
		}
	});
});

function next($postValues) {
						 
	var data = {
				// send start, end, and diff times plus question title (as backup) and content
				question: "" + $( ".title" ).text(),
				startT: $start.toISOString().slice(0, 19).replace('T', ' '),
				endT: $end.toISOString().slice(0, 19).replace('T', ' '),
				timeT: ($end - $start)/1000,
				values: $postValues
		};
			// console.log(data);
	var test = $.post( "php/store.php",
			data
		,
		function($response) {
			// console.log($response);
			$response = ($response);
			
			// if returns error, something went worng
			if ($response.question != "error") {
				// add question content to site
				$( "#question" ).html($response.question);
				
				// update page numbering to see progress
				$( "#progress" ).text("Page " + $response.page + " of " + $response.maxPages);
				$page = $response.page;
				
				// reset all highlightings in code
				$( ".selectedNumber" ).toggleClass( "selectedNumber" );
				$( ".selectedLine" ).toggleClass( "selectedLine" );
				$( ".selectedResponse" ).toggleClass( "selectedResponse" );
				
				// if we got code from the server
				if ($response.code) {
					$code = JSON.parse($response.code);
					
					// i is used to indicate that multiple files have been received
					$i = 0;
					for ($file in $code) {
						// add each file to the selection panel
						$( "#files" ).append("<div class='fileSelect'>" + $file + "</div>");
						
						if ($i == 0) {
							// if its the first of multiple files, show the code and set file as selected in selector panel, other wise hide the appended code (class inActive)
							$( "#codeExample" ).append( "<div id='" + $file.replace(/\./g,"") + "' class='codeSnipet'>" + $code[$file] + "</div>");
							$( ".fileSelect" ).toggleClass("selectedFile");
						}
						else $( "#codeExample" ).append( "<div id=" + $file.replace(/\./g, "") + " class='codeSnipet inActive'>" + $code[$file] + "</div>");
						
						$i++;
					}
					
					// only if there are multiple lines show the file selector and add its highlighting and selection logic
					if ($i > 1) {
						$( "#fileSelector" ).removeClass( "inActive" );
						
						$( ".fileSelect" ).on("click", function(e) {
							$( ".selectedFile" ).toggleClass( "selectedFile" );
							$( this ).toggleClass( "selectedFile" );
							
							$( ".codeSnipet" ).removeClass( "inActive" );
							$( ".codeSnipet" ).addClass("inActive");
							$( "#" + $( this ).html().replace(/\./g,"") ).removeClass( "inActive" );
						});
	  
						// make file selector collapsable
						$( "#fileSelector" ).accordion({
							collapsible: true,
							icons: icons,
							animate: 0
						}).on( "accordionactivate", function( event, ui ) {
							$( "#content" ).css( "margin-top", ($( "#fixed" ).height() +15) );
						});
					}
					
					// whenever the mouse is released, free the clicked variable
					$( document ).on("mouseup", function(e) {
						if ($mouse) $mouse = false;
					});
					
					// this is to ensure the correct code highlighting (keywords and numbers are marked with a span in the code files)
					$( ".string" ).children( "span" ).removeClass();
				}
					
				// check whether selection should be possible on that page and if some initial highlighting is requested
				if ($response.example) {
	 
						
					$example = JSON.parse($response.example);
/*					if ($.isArray($example)) {
						// to be sure that the elements are shown
						$( "#codeExample" ).removeClass("inActive");
						if ($( "#files").children().length > 1) $( "#fileSelector" ).removeClass("inActive");
						for ($lineToMark in $example) {
							$( "#" + $example[$lineToMark].replace(/\./g,"\\.") ).toggleClass( "selectedLine" ).children( ".lineNumber" ).toggleClass( "selectedNumber" );
						}
					}
					// allow highlighting for convenience (they are not part of the answer, but the users may want to be able to mark the code
					else {*/
						if ($example === "hide") {
							$( ".line" ).off();
							$( "#codeExample" ).addClass("inActive");
							$( "#fileSelector" ).addClass("inActive");
						}
						else {
							// to be sure that the elements are shown
							$( "#codeExample" ).removeClass("inActive");
							if ($( "#files").children().length > 1) $( "#fileSelector" ).removeClass("inActive");
							$( ".line" ).off().on("mousedown", function(e) {
								// click selection
	 
								$( this ).children( ".lineNumber" ).toggleClass( "selectedNumber" );
								$( this ).toggleClass( "selectedLine" );
								$mouse = true;
							}).on("mouseenter", function(e) {
								// hovering selection
								if ($mouse) {
									$( this ).children( ".lineNumber" ).toggleClass( "selectedNumber" );
									$( this ).toggleClass( "selectedLine" );
								}
							});
						}
//					}
				}
				else {
					// to be sure that the elements are shown
					$( "#codeExample" ).removeClass("inActive");
					if ($( "#files").children().length > 1) $( "#fileSelector" ).removeClass("inActive");
					// this is a bit tricky, on click but also on click and hover, lines of the example shall be selected (highlighted) and deselected - problems are that the cursor can be too fast and that if the cursor goes back, the most bottom/top line will stay selected (not much to do about it without lots of code imo)
					// free all binds to avoid multibinds
					$( ".line" ).off().on("mousedown", function(e) {
						// click selection
						$( this ).children( ".lineNumber" ).toggleClass( "selectedNumber" );
						$( this ).toggleClass( "selectedLine" ).toggleClass( "selectedResponse" );
						$mouse = true;
					}).on("mouseenter", function(e) {
						// hovering selection
						if ($mouse) {
							$( this ).children( ".lineNumber" ).toggleClass( "selectedNumber" );
							$( this ).toggleClass( "selectedLine" ).toggleClass( "selectedResponse" );
						}
					});
				}
				
				// make items collapsable
				$( ".collapse" ).accordion({
					collapsible: true,
					icons: icons,
					animate: 0
				}).on( "accordionactivate", function( event, ui ) {
					$( "#content" ).css( "margin-top", ($( "#fixed" ).height() +15) );
				});
				
				// correctly position the content of added content and go back to the top
				$( "#content" ).css( "margin-top", ($( "#fixed" ).height() +15) );
				$( "body" ).scrollTop(0);
				
				// in case there was an error
				$( "#next" ).removeClass("inActive");
				
				// if we reached the (pre-)last page, hide some elements
				if ($response.page == $response.maxPages -1) {
					$( "#codeExample" ).addClass("inActive");
					$( "#fileSelector" ).addClass("inActive");
					$( "#fixed" ).css("position", "absolute");
				}
				if ($response.page == $response.maxPages) {
					$( "#content" ).addClass("inActive");
					$( "#next" ).addClass("inActive");
				}
				
				// start new time for next question
				$start = new Date();
			} else {
				// there was an error
				alert("There may have been an error with the connection, please try again! Otherweise, you may not be considered for an experiment right now (did you register or just answer one maybe?).")
				$( "#next" ).addClass("inActive");
			}
		},"json"
	).fail(function(XMLHttpRequest, textStatus, errorThrown) {
    console.log( XMLHttpRequest);
    console.log( textStatus);
    console.log( errorThrown);
  });
}