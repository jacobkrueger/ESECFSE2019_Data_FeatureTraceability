##### Badge Applications

We want to apply for the Reusable and Available Badges.

Reusable badge: The source code  and results of our experiment are reusable and documented (see readme file).

Available badge: All of our results and source code are/will be put in a public repository. Currently, the blinded versions are in a Dropbox folder (for review), but we will put them into a n additional GitHub and/or BitBucket repository in unblinded form and with the same information as for the Artifact evaluation.