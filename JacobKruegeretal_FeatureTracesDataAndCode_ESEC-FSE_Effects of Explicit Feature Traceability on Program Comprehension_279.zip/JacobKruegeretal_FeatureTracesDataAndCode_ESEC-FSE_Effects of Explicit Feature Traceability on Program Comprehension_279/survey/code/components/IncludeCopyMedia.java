<div id='IncludeCopyMedia.java_1' class='line'><div class='lineNumber' id='hl_1'>1 |</div><div class='code'><span class='keyword'>public</span> <span class='keyword'>class</span> IncludeCopyMedia {</div> </div>
<div id='IncludeCopyMedia.java_2' class='line'><div class='lineNumber' id='hl_2'>2 |</div><div class='code'><span class='empty'> </span></div> </div>
<div id='IncludeCopyMedia.java_3' class='line'><div class='lineNumber' id='hl_3'>3 |</div><div class='code'>  <span class='keyword'>public</span> <span class='keyword'>static</span> <span class='keyword'>void</span> addControler(AbstractController nextcontroller, PhotoViewScreen canv) {</div> </div>
<div id='IncludeCopyMedia.java_4' class='line'><div class='lineNumber' id='hl_4'>4 |</div><div class='code'>    PhotoViewController controller = <span class='keyword'>new</span> PhotoViewController(midlet, getAlbumData(), (AlbumListScreen) getAlbumListScreen(), name);</div> </div>
<div id='IncludeCopyMedia.java_5' class='line'><div class='lineNumber' id='hl_5'>5 |</div><div class='code'>    controller.<wbr>setNextController(nextcontroller);</div> </div>
<div id='IncludeCopyMedia.java_6' class='line'><div class='lineNumber' id='hl_6'>6 |</div><div class='code'>    canv.<wbr>setCommandListener(controller);</div> </div>
<div id='IncludeCopyMedia.java_7' class='line'><div class='lineNumber' id='hl_7'>7 |</div><div class='code'>    nextcontroller = controller;</div> </div>
<div id='IncludeCopyMedia.java_8' class='line'><div class='lineNumber' id='hl_8'>8 |</div><div class='code'>  }</div> </div>
<div id='IncludeCopyMedia.java_9' class='line'><div class='lineNumber' id='hl_9'>9 |</div><div class='code'><span class='empty'> </span></div> </div>
<div id='IncludeCopyMedia.java_10' class='line'><div class='lineNumber' id='hl_10'>10 |</div><div class='code'>  <span class='keyword'>public</span> <span class='keyword'>static</span> <span class='keyword'>void</span> setMediaName(String selectedMediaName) {</div> </div>
<div id='IncludeCopyMedia.java_11' class='line'><div class='lineNumber' id='hl_11'>11 |</div><div class='code'>    controller.<wbr>setMediaName(selectedMediaName);</div> </div>
<div id='IncludeCopyMedia.java_12' class='line'><div class='lineNumber' id='hl_12'>12 |</div><div class='code'>  }</div> </div>
<div id='IncludeCopyMedia.java_13' class='line'><div class='lineNumber' id='hl_13'>13 |</div><div class='code'>}</div> </div>

