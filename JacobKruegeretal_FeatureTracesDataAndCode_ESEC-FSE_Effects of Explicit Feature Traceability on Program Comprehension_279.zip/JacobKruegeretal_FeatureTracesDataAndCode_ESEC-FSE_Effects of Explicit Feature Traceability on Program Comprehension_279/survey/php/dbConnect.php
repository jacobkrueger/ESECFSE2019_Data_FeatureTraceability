<?php

$server = "127.0.0.1";
$dbUser = "root";
$pw = "";
$db = "experiment_replicate";
$usersTable = "users";

?>