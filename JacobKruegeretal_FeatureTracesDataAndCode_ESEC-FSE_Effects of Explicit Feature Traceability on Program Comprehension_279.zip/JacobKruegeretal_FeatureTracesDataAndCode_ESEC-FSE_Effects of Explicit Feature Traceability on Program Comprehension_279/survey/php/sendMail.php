<?php

include ("dbConnect.php");
require_once ("Net/SMTP.php");
require_once ("Mail.php");
require_once('Mail/mime.php');

define('CHARSET', 'UTF-8');

// get user data
$connection = mysqli_connect($server, $dbUser, $pw, $db) or die();
$userData = $connection->query("SELECT * FROM {$usersTable} where exp_1_sent is null limit 5");

// loop through all users
while ($nextUser = $userData->fetch_assoc()) {
	// this is a bit clumsy but it should be working and is simple
	$send = 0;

	// have to send 1st experiment
	if (!ISSET($nextUser["exp_1_sent"])) $send = 1;
	
	if ($send != 0) {
		$url = "localhost/survey/index.php?id=".$nextUser["urlkey"];
			
		// send mail
		$from = "";
		$to = $nextUser["mail"];
		$subject = "Invitation to Experiment on Program Comprehension";
		$body =  ("Dear participant,</br></br>thank you very much for supporting us in this experiment!</br></br>You can access the current experiment under the following link:</br></br>{$url}</br></br>If you have any question, you can simply reply to this mail.</br></br>Thank you again for your help,</br>Jacob Kr&#xFC;ger, G&#xFC;l Cal&#x131;kl&#x131;, Thorsten Berger, Thomas Leich, and Gunter Saake");
		
		$crlf = "\r\n";
		$host = "";	
		$username = "";
		$password = "";
		$headers = array (
			'From' => $from,
			'Reply-To' => $from,
			'X-Mailer' => 'PHP/' . phpversion(),
			'MIME-Version' => '1.0',
			'To' => $to,
			'Subject' => $subject,
			'Content-Transfer-Encoding' => 'quoted-printable',
			'Content-type' => 'text/html; charset=UTF-8');
		
		// Creating the Mime message
		$mime = new Mail_mime($crlf);
		// $mime->setTXTBody($text);
		$mime->setHTMLBody($body);
		
		$body = $mime->get();
		$headers = $mime->headers($headers);
		
		 $smtp = Mail::factory('smtp',
		  array ('host' => $host,
			'auth' => true,
			'port' => 587,
			'username' => $username,
			'password' => $password
			)); 
		
		$mail = $smtp->send($to, $headers, $body);

		// update database
		if (PEAR::isError($mail))
			echo("Error: " . $mail->getMessage());
		 else {
			$update =
				"UPDATE ".$usersTable." SET
				exp_".$send."_sent='".date("Y-m-d H:i:s")."'
				WHERE urlkey='".$nextUser["urlkey"]."'";
				
				if ($connection->query($update) === true) ;
				else echo "Something went wrong while inserting user keys: ".mysqli_error($connection);
		 }
	}
}

?>