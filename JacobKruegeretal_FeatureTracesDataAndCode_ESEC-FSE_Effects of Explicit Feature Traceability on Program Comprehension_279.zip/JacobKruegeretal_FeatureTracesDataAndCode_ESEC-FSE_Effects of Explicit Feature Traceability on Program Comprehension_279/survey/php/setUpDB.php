<?php

include ("dbConnect.php");

$createDB =
	"CREATE DATABASE IF NOT EXISTS ".$db;

$createUserTable =
	"CREATE TABLE IF NOT EXISTS ".$usersTable." (
		id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
		urlkey VARCHAR(50) NOT NULL,
		mail VARCHAR(50),
		code VARCHAR(20),
		exp_1_sent DATETIME,
		exp_1_response DATETIME
	)";

$createExperiment1Table =
	"CREATE TABLE IF NOT EXISTS exp1 (
		id INT(10) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
		userkey VARCHAR(50),
		page INT(3),
		question VARCHAR(50),
		starttime DATETIME,
		endtime DATETIME,
		time VARCHAR(50),
		response TEXT
	)";

$connection = mysqli_connect($server, $dbUser, $pw) or die();

if ($connection) {
	// create db
	if ($connection->query($createDB) === true) {
		
		$connection = mysqli_connect($server, $dbUser, $pw, $db) or die();
		// create tables
		if ($connection) {
			
			// insert users
			if ($connection->query($createUserTable) === true) {
				
				$userList = file("../participants.txt", FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
				
				foreach ($userList as $nextUser) {
					$nextUser = explode(",", $nextUser);
					// $insertUsers =
						// "INSERT INTO ".$usersTable." (mail)
						// SELECT * FROM (SELECT '".$nextUser[0]."') AS tmpfile LIMIT 1
						// ";
						$insertUsers =
						"INSERT INTO ".$usersTable." (mail)
						SELECT * FROM (SELECT '".$nextUser[0]."') AS tmpfile
						WHERE NOT EXISTS (
							SELECT mail FROM ".$usersTable." WHERE mail='".$nextUser[0]."') LIMIT 1
						";
					
					if ($connection->query($insertUsers) === true) {
						// assign key and code type
						$assignKey =
							"UPDATE ".$usersTable." SET
							urlkey='".md5(mysqli_insert_id($connection).$nextUser[0])."',
							code='".$nextUser[1]."'
							WHERE id='".mysqli_insert_id($connection)."'";
						
						if ($connection->query($assignKey) === true) ;
						else echo "Something went wrong while inserting user keys: ".mysqli_error($connection);
					}
					else echo "Something went wrong while inserting user data: ".mysqli_error($connection);
				}
				
			}
			else echo "Something went wrong while creating user table: ".$connection->connect_error;
			
			// set up experiment tables
			if ($connection->query($createExperiment1Table) === true) ;
			else echo "Something went wrong while creating experiment tables: ".mysqli_error($connection);
		}
		else die( "Something went wrong while connecting to db: ".mysqli_connect_error());
		
	}
	else echo "Something went wrong while creating databse: ".mysqli_error($connection);
	
}
else die( "Something went wrong while connecting to server: ".mysqli_connect_error());

?>