<?php
	// identify user and set page number if new user based on url variable
	session_start();
	if (!ISSET($_SESSION["id"]) || $_SESSION["id"] !== $_GET["id"]) {
		$_SESSION["id"] = $_GET["id"];
		$_SESSION["page"] = 1;
	}
?>

<html>

<head>
	<script type="text/javascript" src="js/jquery-3.3.1.min.js"> </script>
	<script type="text/javascript" src="js/jquery-ui-1.12.1.custom/jquery-ui.min.js"> </script>
	<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
	
	<script type="text/javascript" src="js/functions.js"> </script>
	
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<link rel="stylesheet" type="text/css" href="css/codeStyles.css">
	
	<title> Program Comprehension Survey </title>
</head>

<body>

<div id="header"></div>

<div id="footer"></div>

<div id="fixed">
	<div id="question">	</div>
	
	<div id="baseline">
		<div id="progress"> </div>
		
		<div id="next"> NEXT </div>
	</div>
	
	<div id="separator"> </div>
	
	<div id="fileSelector" class="inActive">
		<h3> Files </h3>
		<div id="files"> </div>
	</div>
</div>

<div id="content">
	<div id="codeExample"> </div>
<div>
</body>

</html>