<div id='CaptureVideo.java_1' class='line'><div class='lineNumber' id='hl_1'>1 |</div><div class='code'><span class='keyword'>public</span> <span class='keyword'>class</span> CaptureVideo {</div> </div>
<div id='CaptureVideo.java_2' class='line'><div class='lineNumber' id='hl_2'>2 |</div><div class='code'><span class='empty'> </span></div> </div>
<div id='CaptureVideo.java_3' class='line'><div class='lineNumber' id='hl_3'>3 |</div><div class='code'>  <span class='keyword'>public</span> <span class='keyword'>static</span> <span class='keyword'>boolean</span> checkLabel(String label) {</div> </div>
<div id='CaptureVideo.java_4' class='line'><div class='lineNumber' id='hl_4'>4 |</div><div class='code'>    <span class='keyword'>if</span> (label.<wbr>equals(<span class='string'>"Capture Video"</span>)) {</div> </div>
<div id='CaptureVideo.java_5' class='line'><div class='lineNumber' id='hl_5'>5 |</div><div class='code'>      CaptureVideoScreen playscree = <span class='keyword'>new</span> CaptureVideoScreen(midlet, CaptureVideoScreen.<wbr>CAPTUREVIDEO);</div> </div>
<div id='CaptureVideo.java_6' class='line'><div class='lineNumber' id='hl_6'>6 |</div><div class='code'>      playscree.<wbr>setVisibleVideo();</div> </div>
<div id='CaptureVideo.java_7' class='line'><div class='lineNumber' id='hl_7'>7 |</div><div class='code'>      VideoCaptureController controller = <span class='keyword'>new</span> VideoCaptureController(midlet, getAlbumData(), (AlbumListScreen) getAlbumListScreen(), playscree);</div> </div>
<div id='CaptureVideo.java_8' class='line'><div class='lineNumber' id='hl_8'>8 |</div><div class='code'>      <span class='keyword'>this</span>.<wbr>setNextController(controller);</div> </div>
<div id='CaptureVideo.java_9' class='line'><div class='lineNumber' id='hl_9'>9 |</div><div class='code'>      playscree.<wbr>setCommandListener(<span class='keyword'>this</span>);</div> </div>
<div id='CaptureVideo.java_10' class='line'><div class='lineNumber' id='hl_10'>10 |</div><div class='code'>      <span class='keyword'>return</span> <span class='keyword'>true</span>;    </div> </div>
<div id='CaptureVideo.java_11' class='line'><div class='lineNumber' id='hl_11'>11 |</div><div class='code'>    }</div> </div>
<div id='CaptureVideo.java_12' class='line'><div class='lineNumber' id='hl_12'>12 |</div><div class='code'>    <span class='keyword'>return</span> <span class='keyword'>false</span>;</div> </div>
<div id='CaptureVideo.java_13' class='line'><div class='lineNumber' id='hl_13'>13 |</div><div class='code'>  }</div> </div>
<div id='CaptureVideo.java_14' class='line'><div class='lineNumber' id='hl_14'>14 |</div><div class='code'>}</div> </div>

