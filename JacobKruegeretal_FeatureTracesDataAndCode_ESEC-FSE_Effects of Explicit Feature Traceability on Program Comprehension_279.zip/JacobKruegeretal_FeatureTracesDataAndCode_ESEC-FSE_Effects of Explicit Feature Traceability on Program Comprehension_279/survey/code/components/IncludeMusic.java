<div id='IncludeMusic.java_1' class='line'><div class='lineNumber' id='hl_1'>1 |</div><div class='code'><span class='keyword'>public</span> <span class='keyword'>class</span> IncludeMusic {</div> </div>
<div id='IncludeMusic.java_2' class='line'><div class='lineNumber' id='hl_2'>2 |</div><div class='code'><span class='empty'> </span></div> </div>
<div id='IncludeMusic.java_3' class='line'><div class='lineNumber' id='hl_3'>3 |</div><div class='code'>  <span class='keyword'>public</span> <span class='keyword'>static</span> <span class='keyword'>boolean</span> checkLabel(String label) {</div> </div>
<div id='IncludeMusic.java_4' class='line'><div class='lineNumber' id='hl_4'>4 |</div><div class='code'>    <span class='keyword'>if</span> (label.<wbr>equals(<span class='string'>"Play"</span>)) {</div> </div>
<div id='IncludeMusic.java_5' class='line'><div class='lineNumber' id='hl_5'>5 |</div><div class='code'>      String selectedMediaName = getSelectedMediaName();</div> </div>
<div id='IncludeMusic.java_6' class='line'><div class='lineNumber' id='hl_6'>6 |</div><div class='code'>      <span class='keyword'>return</span> playMusicMedia(selectedMediaName);</div> </div>
<div id='IncludeMusic.java_7' class='line'><div class='lineNumber' id='hl_7'>7 |</div><div class='code'>    }</div> </div>
<div id='IncludeMusic.java_8' class='line'><div class='lineNumber' id='hl_8'>8 |</div><div class='code'>    <span class='keyword'>return</span> <span class='keyword'>false</span>;</div> </div>
<div id='IncludeMusic.java_9' class='line'><div class='lineNumber' id='hl_9'>9 |</div><div class='code'>  }</div> </div>
<div id='IncludeMusic.java_10' class='line'><div class='lineNumber' id='hl_10'>10 |</div><div class='code'><span class='empty'> </span></div> </div>
<div id='IncludeMusic.java_11' class='line'><div class='lineNumber' id='hl_11'>11 |</div><div class='code'>  <span class='keyword'>private</span> <span class='keyword'>static</span> <span class='keyword'>boolean</span> playMusicMedia(String selectedMediaName) {</div> </div>
<div id='IncludeMusic.java_12' class='line'><div class='lineNumber' id='hl_12'>12 |</div><div class='code'>    InputStream storedMusic = <span class='keyword'>null</span>;</div> </div>
<div id='IncludeMusic.java_13' class='line'><div class='lineNumber' id='hl_13'>13 |</div><div class='code'>    <span class='keyword'>try</span> {</div> </div>
<div id='IncludeMusic.java_14' class='line'><div class='lineNumber' id='hl_14'>14 |</div><div class='code'>      MediaData mymedia = getAlbumData().<wbr>getMediaInfo(selectedMediaName);</div> </div>
<div id='IncludeMusic.java_15' class='line'><div class='lineNumber' id='hl_15'>15 |</div><div class='code'>      IncludeSorting.<wbr>incrementCountViews(selectedMediaName);</div> </div>
<div id='IncludeMusic.java_16' class='line'><div class='lineNumber' id='hl_16'>16 |</div><div class='code'>      <span class='keyword'>if</span> (mymedia.<wbr>getTypeMedia().<wbr>equals(MediaData.<wbr>MUSIC)) {</div> </div>
<div id='IncludeMusic.java_17' class='line'><div class='lineNumber' id='hl_17'>17 |</div><div class='code'>        storedMusic = ((MusicAlbumData) getAlbumData()).<wbr>getMusicFromRecordStore(getCurrentStoreName(), selectedMediaName);</div> </div>
<div id='IncludeMusic.java_18' class='line'><div class='lineNumber' id='hl_18'>18 |</div><div class='code'>        PlayMediaScreen playscree = <span class='keyword'>new</span> PlayMediaScreen(midlet,storedMusic, mymedia.<wbr>getTypeMedia(),<span class='keyword'>this</span>);</div> </div>
<div id='IncludeMusic.java_19' class='line'><div class='lineNumber' id='hl_19'>19 |</div><div class='code'>        MusicPlayController controller = <span class='keyword'>new</span> MusicPlayController(midlet, getAlbumData(), (AlbumListScreen) getAlbumListScreen(), playscree);</div> </div>
<div id='IncludeMusic.java_20' class='line'><div class='lineNumber' id='hl_20'>20 |</div><div class='code'>        IncludeCopyMedia.<wbr>setMediaName(selectedMediaName);</div> </div>
<div id='IncludeMusic.java_21' class='line'><div class='lineNumber' id='hl_21'>21 |</div><div class='code'><span class='empty'> </span></div> </div>
<div id='IncludeMusic.java_22' class='line'><div class='lineNumber' id='hl_22'>22 |</div><div class='code'>        <span class='keyword'>this</span>.<wbr>setNextController(controller);</div> </div>
<div id='IncludeMusic.java_23' class='line'><div class='lineNumber' id='hl_23'>23 |</div><div class='code'>      }</div> </div>
<div id='IncludeMusic.java_24' class='line'><div class='lineNumber' id='hl_24'>24 |</div><div class='code'>      <span class='keyword'>return</span> <span class='keyword'>true</span>;</div> </div>
<div id='IncludeMusic.java_25' class='line'><div class='lineNumber' id='hl_25'>25 |</div><div class='code'>    } <span class='keyword'>catch</span> (ImageNotFoundException e) {</div> </div>
<div id='IncludeMusic.java_26' class='line'><div class='lineNumber' id='hl_26'>26 |</div><div class='code'>      Alert alert = <span class='keyword'>new</span> Alert( <span class='string'>"Error"</span>, <span class='string'>"The selected item was not found in the mobile device"</span>, <span class='keyword'>null</span>, AlertType.<wbr>ERROR);</div> </div>
<div id='IncludeMusic.java_27' class='line'><div class='lineNumber' id='hl_27'>27 |</div><div class='code'>      Display.<wbr>getDisplay(midlet).<wbr>setCurrent(alert, Display.<wbr>getDisplay(midlet).<wbr>getCurrent());</div> </div>
<div id='IncludeMusic.java_28' class='line'><div class='lineNumber' id='hl_28'>28 |</div><div class='code'>        <span class='keyword'>return</span> <span class='keyword'>false</span>;</div> </div>
<div id='IncludeMusic.java_29' class='line'><div class='lineNumber' id='hl_29'>29 |</div><div class='code'>    } <span class='keyword'>catch</span> (PersistenceMechanismException e) {</div> </div>
<div id='IncludeMusic.java_30' class='line'><div class='lineNumber' id='hl_30'>30 |</div><div class='code'>      Alert alert = <span class='keyword'>new</span> Alert( <span class='string'>"Error"</span>, <span class='string'>"The mobile database can open <span class='keyword'>this</span> item <span class='number'>1</span>"</span>, <span class='keyword'>null</span>, AlertType.<wbr>ERROR);</div> </div>
<div id='IncludeMusic.java_31' class='line'><div class='lineNumber' id='hl_31'>31 |</div><div class='code'>      Display.<wbr>getDisplay(midlet).<wbr>setCurrent(alert, Display.<wbr>getDisplay(midlet).<wbr>getCurrent());</div> </div>
<div id='IncludeMusic.java_32' class='line'><div class='lineNumber' id='hl_32'>32 |</div><div class='code'>      <span class='keyword'>return</span> <span class='keyword'>false</span>;</div> </div>
<div id='IncludeMusic.java_33' class='line'><div class='lineNumber' id='hl_33'>33 |</div><div class='code'>    }</div> </div>
<div id='IncludeMusic.java_34' class='line'><div class='lineNumber' id='hl_34'>34 |</div><div class='code'>  }</div> </div>
<div id='IncludeMusic.java_35' class='line'><div class='lineNumber' id='hl_35'>35 |</div><div class='code'><span class='empty'> </span></div> </div>
<div id='IncludeMusic.java_36' class='line'><div class='lineNumber' id='hl_36'>36 |</div><div class='code'>  <span class='keyword'>public</span> <span class='keyword'>static</span> <span class='keyword'>void</span> album {</div> </div>
<div id='IncludeMusic.java_37' class='line'><div class='lineNumber' id='hl_37'>37 |</div><div class='code'>    <span class='keyword'>try</span> {</div> </div>
<div id='IncludeMusic.java_38' class='line'><div class='lineNumber' id='hl_38'>38 |</div><div class='code'>      <span class='keyword'>if</span> (getAlbumData() <span class='keyword'>instanceof</span> MusicAlbumData){</div> </div>
<div id='IncludeMusic.java_39' class='line'><div class='lineNumber' id='hl_39'>39 |</div><div class='code'>        getAlbumData().<wbr>loadMediaDataFromRMS(getCurrentStoreName());</div> </div>
<div id='IncludeMusic.java_40' class='line'><div class='lineNumber' id='hl_40'>40 |</div><div class='code'>        MediaData mymedia = getAlbumData().<wbr>getMediaInfo(((AddMediaToAlbum) getCurrentScreen()).<wbr>getItemName());</div> </div>
<div id='IncludeMusic.java_41' class='line'><div class='lineNumber' id='hl_41'>41 |</div><div class='code'>        mymedia.<wbr>setTypeMedia( ((AddMediaToAlbum) getCurrentScreen()).<wbr>getItemType() );</div> </div>
<div id='IncludeMusic.java_42' class='line'><div class='lineNumber' id='hl_42'>42 |</div><div class='code'>        getAlbumData().<wbr>updateMediaInfo(mymedia, mymedia);</div> </div>
<div id='IncludeMusic.java_43' class='line'><div class='lineNumber' id='hl_43'>43 |</div><div class='code'>      }</div> </div>
<div id='IncludeMusic.java_44' class='line'><div class='lineNumber' id='hl_44'>44 |</div><div class='code'>    } <span class='keyword'>catch</span> (ImageNotFoundException e) {</div> </div>
<div id='IncludeMusic.java_45' class='line'><div class='lineNumber' id='hl_45'>45 |</div><div class='code'>      Alert alert = <span class='keyword'>new</span> Alert(<span class='string'>"Error"</span>, <span class='string'>"The selected item was not found in the mobile device"</span>, <span class='keyword'>null</span>, AlertType.<wbr>ERROR);</div> </div>
<div id='IncludeMusic.java_46' class='line'><div class='lineNumber' id='hl_46'>46 |</div><div class='code'>      Display.<wbr>getDisplay(midlet).<wbr>setCurrent(alert, Display.<wbr>getDisplay(midlet).<wbr>getCurrent());</div> </div>
<div id='IncludeMusic.java_47' class='line'><div class='lineNumber' id='hl_47'>47 |</div><div class='code'>      <span class='keyword'>return</span> <span class='keyword'>true</span>;</div> </div>
<div id='IncludeMusic.java_48' class='line'><div class='lineNumber' id='hl_48'>48 |</div><div class='code'>    }</div> </div>
<div id='IncludeMusic.java_49' class='line'><div class='lineNumber' id='hl_49'>49 |</div><div class='code'>  }</div> </div>
<div id='IncludeMusic.java_50' class='line'><div class='lineNumber' id='hl_50'>50 |</div><div class='code'>}</div> </div>

