How to set up the experiment with an unprotected server in XAMPP and without mail sending capabilities:
1. Download and isntall XAMPP: <https://www.apachefriends.org/de/index.html>
2. Start Apache Server and MySQL
3. Define user, password etc. fot the database in dbConnect.php
4. Set up participants.txt in the form: mail,code; where code can be one of the following: "annotated","components" or "object-oriented", depending on the version the participant shall see
5. Execute <http://localhost/survey/php/setUpDB.php> to set up the database, all tables and the experiment
6. We remark again that we disabled automated mail sending! For this reason, you have to manually set exp_1_sent to a value (the current date), otherwise the system will not recognize that the user was already invited
7. Then, you can go into a browser and call: localhost/survey/index.php?id=-id- ; where -id- refers to the urlkey entry in the user tables
8. This should result in the experiment running and storing data
9. To access and see the resulting data, go into phpMyAdmin and have a look into the databases that store the corresponding data
