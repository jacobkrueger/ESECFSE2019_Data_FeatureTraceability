<div id='IncludeVideo.java_1' class='line'><div class='lineNumber' id='hl_1'>1 |</div><div class='code'><span class='keyword'>public</span> <span class='keyword'>class</span> IncludeVideo {</div> </div>
<div id='IncludeVideo.java_2' class='line'><div class='lineNumber' id='hl_2'>2 |</div><div class='code'><span class='empty'> </span></div> </div>
<div id='IncludeVideo.java_3' class='line'><div class='lineNumber' id='hl_3'>3 |</div><div class='code'>  <span class='keyword'>public</span> <span class='keyword'>static</span> <span class='keyword'>boolean</span> checkLabel(String label) {</div> </div>
<div id='IncludeVideo.java_4' class='line'><div class='lineNumber' id='hl_4'>4 |</div><div class='code'>    <span class='keyword'>if</span> (label.<wbr>equals(<span class='string'>"Play Video"</span>)) {</div> </div>
<div id='IncludeVideo.java_5' class='line'><div class='lineNumber' id='hl_5'>5 |</div><div class='code'>      String selectedMediaName = getSelectedMediaName();</div> </div>
<div id='IncludeVideo.java_6' class='line'><div class='lineNumber' id='hl_6'>6 |</div><div class='code'>      <span class='keyword'>return</span> playVideoMedia(selectedMediaName);</div> </div>
<div id='IncludeVideo.java_7' class='line'><div class='lineNumber' id='hl_7'>7 |</div><div class='code'>    }</div> </div>
<div id='IncludeVideo.java_8' class='line'><div class='lineNumber' id='hl_8'>8 |</div><div class='code'>    <span class='keyword'>return</span> <span class='keyword'>false</span>;</div> </div>
<div id='IncludeVideo.java_9' class='line'><div class='lineNumber' id='hl_9'>9 |</div><div class='code'>  }</div> </div>
<div id='IncludeVideo.java_10' class='line'><div class='lineNumber' id='hl_10'>10 |</div><div class='code'><span class='empty'> </span></div> </div>
<div id='IncludeVideo.java_11' class='line'><div class='lineNumber' id='hl_11'>11 |</div><div class='code'>  <span class='keyword'>private</span> <span class='keyword'>static</span> <span class='keyword'>boolean</span> playVideoMedia(String selectedMediaName) {</div> </div>
<div id='IncludeVideo.java_12' class='line'><div class='lineNumber' id='hl_12'>12 |</div><div class='code'>    InputStream storedMusic = <span class='keyword'>null</span>;</div> </div>
<div id='IncludeVideo.java_13' class='line'><div class='lineNumber' id='hl_13'>13 |</div><div class='code'>    <span class='keyword'>try</span> {</div> </div>
<div id='IncludeVideo.java_14' class='line'><div class='lineNumber' id='hl_14'>14 |</div><div class='code'>      MediaData mymedia = getAlbumData().<wbr>getMediaInfo(selectedMediaName);</div> </div>
<div id='IncludeVideo.java_15' class='line'><div class='lineNumber' id='hl_15'>15 |</div><div class='code'>      IncludeSorting.<wbr>incrementCountViews(selectedMediaName++);</div> </div>
<div id='IncludeVideo.java_16' class='line'><div class='lineNumber' id='hl_16'>16 |</div><div class='code'>      <span class='keyword'>if</span> (mymedia.<wbr>getTypeMedia().<wbr>equals(MediaData.<wbr>VIDEO)) {</div> </div>
<div id='IncludeVideo.java_17' class='line'><div class='lineNumber' id='hl_17'>17 |</div><div class='code'>        storedMusic = ((VideoAlbumData) getAlbumData()).<wbr>getVideoFromRecordStore(getCurrentStoreName(), selectedMediaName);</div> </div>
<div id='IncludeVideo.java_18' class='line'><div class='lineNumber' id='hl_18'>18 |</div><div class='code'>        PlayVideoScreen playscree = <span class='keyword'>new</span> PlayVideoScreen(midlet,storedMusic, mymedia.<wbr>getTypeMedia(),<span class='keyword'>this</span>);</div> </div>
<div id='IncludeVideo.java_19' class='line'><div class='lineNumber' id='hl_19'>19 |</div><div class='code'>        playscree.<wbr>setVisibleVideo();</div> </div>
<div id='IncludeVideo.java_20' class='line'><div class='lineNumber' id='hl_20'>20 |</div><div class='code'>        PlayVideoController controller = <span class='keyword'>new</span> PlayVideoController(midlet, getAlbumData(), (AlbumListScreen) getAlbumListScreen(), playscree);</div> </div>
<div id='IncludeVideo.java_21' class='line'><div class='lineNumber' id='hl_21'>21 |</div><div class='code'>        IncludeCopyMedia.<wbr>setMediaName(selectedMediaName);</div> </div>
<div id='IncludeVideo.java_22' class='line'><div class='lineNumber' id='hl_22'>22 |</div><div class='code'><span class='empty'> </span></div> </div>
<div id='IncludeVideo.java_23' class='line'><div class='lineNumber' id='hl_23'>23 |</div><div class='code'>        <span class='keyword'>this</span>.<wbr>setNextController(controller);</div> </div>
<div id='IncludeVideo.java_24' class='line'><div class='lineNumber' id='hl_24'>24 |</div><div class='code'>      }</div> </div>
<div id='IncludeVideo.java_25' class='line'><div class='lineNumber' id='hl_25'>25 |</div><div class='code'>      <span class='keyword'>return</span> <span class='keyword'>true</span>;</div> </div>
<div id='IncludeVideo.java_26' class='line'><div class='lineNumber' id='hl_26'>26 |</div><div class='code'>    } <span class='keyword'>catch</span> (ImageNotFoundException e) {</div> </div>
<div id='IncludeVideo.java_27' class='line'><div class='lineNumber' id='hl_27'>27 |</div><div class='code'>      Alert alert = <span class='keyword'>new</span> Alert( <span class='string'>"Error"</span>, <span class='string'>"The selected item was not found in the mobile device"</span>, <span class='keyword'>null</span>, AlertType.<wbr>ERROR);</div> </div>
<div id='IncludeVideo.java_28' class='line'><div class='lineNumber' id='hl_28'>28 |</div><div class='code'>      Display.<wbr>getDisplay(midlet).<wbr>setCurrent(alert, Display.<wbr>getDisplay(midlet).<wbr>getCurrent());</div> </div>
<div id='IncludeVideo.java_29' class='line'><div class='lineNumber' id='hl_29'>29 |</div><div class='code'>        <span class='keyword'>return</span> <span class='keyword'>false</span>;</div> </div>
<div id='IncludeVideo.java_30' class='line'><div class='lineNumber' id='hl_30'>30 |</div><div class='code'>    } <span class='keyword'>catch</span> (PersistenceMechanismException e) {</div> </div>
<div id='IncludeVideo.java_31' class='line'><div class='lineNumber' id='hl_31'>31 |</div><div class='code'>      Alert alert = <span class='keyword'>new</span> Alert( <span class='string'>"Error"</span>, <span class='string'>"The mobile database can open <span class='keyword'>this</span> item <span class='number'>1</span>"</span>, <span class='keyword'>null</span>, AlertType.<wbr>ERROR);</div> </div>
<div id='IncludeVideo.java_32' class='line'><div class='lineNumber' id='hl_32'>32 |</div><div class='code'>      Display.<wbr>getDisplay(midlet).<wbr>setCurrent(alert, Display.<wbr>getDisplay(midlet).<wbr>getCurrent());</div> </div>
<div id='IncludeVideo.java_33' class='line'><div class='lineNumber' id='hl_33'>33 |</div><div class='code'>      <span class='keyword'>return</span> <span class='keyword'>false</span>;</div> </div>
<div id='IncludeVideo.java_34' class='line'><div class='lineNumber' id='hl_34'>34 |</div><div class='code'>    }</div> </div>
<div id='IncludeVideo.java_35' class='line'><div class='lineNumber' id='hl_35'>35 |</div><div class='code'>  }</div> </div>
<div id='IncludeVideo.java_36' class='line'><div class='lineNumber' id='hl_36'>36 |</div><div class='code'>}</div> </div>

