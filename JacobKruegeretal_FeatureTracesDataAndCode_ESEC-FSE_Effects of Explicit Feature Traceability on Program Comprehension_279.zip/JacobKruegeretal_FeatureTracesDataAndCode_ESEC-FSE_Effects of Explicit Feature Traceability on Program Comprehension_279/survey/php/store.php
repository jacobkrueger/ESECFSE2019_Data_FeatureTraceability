<?php

require_once ("dbConnect.php");

session_start();

$experiment = 0;
$maxPages;

// get user data
$connection = mysqli_connect($server, $dbUser, $pw, $db) or die();
$sent = $connection->query("SELECT 
	exp_1_sent
FROM users WHERE urlkey='".$_SESSION["id"]."' LIMIT 1");
$sent = $sent->fetch_assoc();

$response =  $connection->query("SELECT 
	exp_1_response
FROM users WHERE urlkey='".$_SESSION["id"]."' LIMIT 1");
$response = $response->fetch_assoc();

if ($sent["exp_1_sent"] !== null && $response["exp_1_response"] === null) $experiment = 1;

// get correct code
$dir = $connection->query("SELECT code
	FROM users WHERE urlkey='".$_SESSION["id"]."' LIMIT 1");
$dir = $dir->fetch_assoc();
$codeType = $dir["code"];

if (!empty($_POST)) {
	$error = false;

	// don't increase stuff if the page is loaded first or reloaded, instead check for correct page number
	if ($_POST["values"] !== "setUp") {
		
		// parse post data
		if ($connection) {
			$insertQuery = "INSERT INTO exp".$experiment." (
					userkey, page, question, starttime, endtime, time, response
				)
				VALUES (
					'".$_SESSION["id"]."', '".$_SESSION["page"]."', '".$_POST["question"]."', '".$_POST["startT"]."', '".$_POST["endT"]."', '".$_POST["timeT"]."', '".addslashes ($_POST["values"])."'
				)";
				// echo $insertQuery;
			if ($connection->query($insertQuery) === true) ;
			else $error = true;
		}
		else $error = true;
		
		// increase page number as its not a set up
		$_SESSION["page"]++;
	}
	else {
		if ($connection) {
			$checkQuery = "SELECT MAX(page) AS page FROM exp".$experiment." WHERE userkey='".$_SESSION["id"]."'";
			
			$pageData = $connection->query($checkQuery);
			if ($pageData) {
				$pageData = $pageData->fetch_assoc();
				
				if ($pageData["page"] != $_SESSION["page"]) $_SESSION["page"] = $pageData["page"] +1;
			}		 
		}
		else $error = true;
	}
	
	// there has been an error
	if ($error === true) {
		echo json_encode(array(
			"question" => "error"
		));
	} else {
		$question = "";
		$code;
		$example;
		switch ($experiment) {
			case 1:
				// set page number for experiments
				$maxPages = 11;
				
				// for the examples on page 2 (and where they have to be deselected
				switch ($_SESSION["page"]) {
/*					case 2: 
						$example = file("../exp".$experiment."/html/".$codeType."/example.txt", FILE_IGNORE_NEW_LINES);
						break;*/
					case 2:
					case 6:
					case 10:
					case 11:
			 
						$example = "hide";
						break;
					case 3:
					case 5:
						$example = "noSelect";
						break;
					default:
						break;
				}
				
				// send code at page 2 and if reload
				if ($_SESSION["page"] === 2 || ($_POST["values"] === "setUp" && $_SESSION["page"] > 2)) {
					
					// load all code files in folder
					if ($directory = opendir("../code/".$codeType."/")) {
						while (($file = readdir($directory)) !== false) {
							if (substr($file, 0, 1) !== ".")
								$code[$file] = file_get_contents("../code/".$codeType."/".$file);
						}
						closedir($directory);
					}
				}
				
				// set page number for experiments
				if (!ISSET($maxPages)) $maxPages = 5;
				
				// read next question from html file
				if (file_exists("../exp".$experiment."/html/".$codeType."/page".$_SESSION["page"].".html"))
					$question = file_get_contents("../exp".$experiment."/html/".$codeType."/page".$_SESSION["page"].".html");
				
				// send respone as long as we are not at the end and add code if necessary
				if ($_SESSION["page"] <= $maxPages) {
					$json = array(
						"maxPages" => $maxPages,
						"page" => $_SESSION["page"],
						"question" => $question
					);
					if (ISSET($code)) $json["code"] = json_encode($code);
					if (ISSET($example)) $json["example"] = json_encode($example);
					
					echo json_encode($json);
				}
				
				// insert finishing date into table
				if ($_SESSION["page"] === $maxPages) {
					$updateUser =
						"UPDATE ".$usersTable." SET
						exp_".$experiment."_response='".$_POST["endT"]."'
						WHERE urlkey='".$_SESSION["id"]."'";
					
					if ($connection->query($updateUser) === true) ;
					else echo json_encode(array(
						"question" => "error"
					));
					
					// remove all session variables
					session_unset();
					session_destroy();
				}
				break;
			// something went wrong
			default:
				echo json_encode(array(
					"question" => "error"
				));
				break;
		}
	}
}

?>